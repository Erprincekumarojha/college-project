package com.dts.pro.bean;

public class AuthorsBean {

	private String AuthorProfile;

	public String getAuthorProfile() {
		return AuthorProfile;
	}

	public void setAuthorProfile(String authorProfile) {
		AuthorProfile = authorProfile;
	}
}
