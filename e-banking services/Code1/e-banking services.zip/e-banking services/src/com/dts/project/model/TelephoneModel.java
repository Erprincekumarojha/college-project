/**
 * 
 */
package com.dts.project.model;

/**
 * @author JAVAPROJECTS
 *
 */
public class TelephoneModel {
	private int telphno;
	private int teltypeid;
	private String teltypename;
	private double amt4min;
	private double othertaxes;
	private int securityno;
	private int talktime;
	private int txid;
	private int custid;
	private String custname;
	private String bilisuedate;
	private String bilpayeddate;
	private double dueamt;
	private double paiedamt;
	private String status;
	private String telissuedate;
	private double amt2pay;
	
	
	public int getTelphno() {
		return telphno;
	}
	public void setTelphno(int telphno) {
		this.telphno = telphno;
	}
	public int getTeltypeid() {
		return teltypeid;
	}
	public void setTeltypeid(int teltypeid) {
		this.teltypeid = teltypeid;
	}
	public String getTeltypename() {
		return teltypename;
	}
	public void setTeltypename(String teltypename) {
		this.teltypename = teltypename;
	}
	public double getAmt4min() {
		return amt4min;
	}
	public void setAmt4min(double amt4min) {
		this.amt4min = amt4min;
	}
	public double getOthertaxes() {
		return othertaxes;
	}
	public void setOthertaxes(double othertaxes) {
		this.othertaxes = othertaxes;
	}
	public int getSecurityno() {
		return securityno;
	}
	public void setSecurityno(int securityno) {
		this.securityno = securityno;
	}
	public int getTalktime() {
		return talktime;
	}
	public void setTalktime(int talktime) {
		this.talktime = talktime;
	}
	public String getBilisuedate() {
		return bilisuedate;
	}
	public void setBilisuedate(String bilisuedate) {
		this.bilisuedate = bilisuedate;
	}
	public String getBilpayeddate() {
		return bilpayeddate;
	}
	public void setBilpayeddate(String bilpayeddate) {
		this.bilpayeddate = bilpayeddate;
	}
	public double getDueamt() {
		return dueamt;
	}
	public void setDueamt(double dueamt) {
		this.dueamt = dueamt;
	}
	public double getPaiedamt() {
		return paiedamt;
	}
	public void setPaiedamt(double paiedamt) {
		this.paiedamt = paiedamt;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getTelissuedate() {
		return telissuedate;
	}
	public void setTelissuedate(String telissuedate) {
		this.telissuedate = telissuedate;
	}
	public double getAmt2pay() {
		return amt2pay;
	}
	public void setAmt2pay(double amt2pay) {
		this.amt2pay = amt2pay;
	}
	public int getTxid() {
		return txid;
	}
	public void setTxid(int txid) {
		this.txid = txid;
	}
	public int getCustid() {
		return custid;
	}
	public void setCustid(int custid) {
		this.custid = custid;
	}
	public String getCustname() {
		return custname;
	}
	public void setCustname(String custname) {
		this.custname = custname;
	}

}
