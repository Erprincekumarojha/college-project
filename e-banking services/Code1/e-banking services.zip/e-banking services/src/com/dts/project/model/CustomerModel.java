package com.dts.project.model;

public class CustomerModel {
private int custid;
private String custfname;
private String custmname;
private String custlname;
private String dob;
private String doj;
private String phno;
private String emailid;
private String logintype;
private String custhno;
private String street;
private String address;
private String adrsprof;
private String gender;
private String city;
private String state;
private String country;
private String custuname;
private String custpass;
private String custphoto;
private String custpin;
private String mstatus;

private int accno;

private int deptid;
private String deptname;

private int desigid;
private String designame;

private int qualid;
private String qualname;

public String getCustphoto() {
	return custphoto;
}
public void setCustphoto(String custphoto) {
	this.custphoto = custphoto;
}
public int getCustid() {
	return custid;
}
public void setCustid(int custid) {
	this.custid = custid;
}
public String getCustfname() {
	return custfname;
}
public void setCustfname(String custfname) {
	this.custfname = custfname;
}
public String getCustmname() {
	return custmname;
}
public void setCustmname(String custmname) {
	this.custmname = custmname;
}
public String getCustlname() {
	return custlname;
}
public void setCustlname(String custlname) {
	this.custlname = custlname;
}
public String getDob() {
	return dob;
}
public void setDob(String dob) {
	this.dob = dob;
}
public String getDoj() {
	return doj;
}
public void setDoj(String doj) {
	this.doj = doj;
}
public String getPhno() {
	return phno;
}
public void setPhno(String phno) {
	this.phno = phno;
}
public String getEmailid() {
	return emailid;
}
public void setEmailid(String emailid) {
	this.emailid = emailid;
}
public String getLogintype() {
	return logintype;
}
public void setLogintype(String logintype) {
	this.logintype = logintype;
}
public String getStreet() {
	return street;
}
public void setStreet(String street) {
	this.street = street;
}
public String getCity() {
	return city;
}
public void setCity(String city) {
	this.city = city;
}
public String getState() {
	return state;
}
public void setState(String state) {
	this.state = state;
}
public String getCountry() {
	return country;
}
public void setCountry(String country) {
	this.country = country;
}
public String getCustuname() {
	return custuname;
}
public void setCustuname(String custuname) {
	this.custuname = custuname;
}
public String getCustpass() {
	return custpass;
}
public void setCustpass(String custpass) {
	this.custpass = custpass;
}
public String getCusthno() {
	return custhno;
}
public void setCusthno(String custhno) {
	this.custhno = custhno;
}
public String getCustpin() {
	return custpin;
}
public void setCustpin(String custpin) {
	this.custpin = custpin;
}
public String getAddress() {
	return address;
}
public void setAddress(String address) {
	this.address = address;
}
public String getAdrsprof() {
	return adrsprof;
}
public void setAdrsprof(String adrsprof) {
	this.adrsprof = adrsprof;
}
public String getGender() {
	return gender;
}
public void setGender(String gender) {
	this.gender = gender;
}
public String getMstatus() {
	return mstatus;
}
public void setMstatus(String mstatus) {
	this.mstatus = mstatus;
}
public int getDeptid() {
	return deptid;
}
public void setDeptid(int deptid) {
	this.deptid = deptid;
}
public String getDeptname() {
	return deptname;
}
public void setDeptname(String deptname) {
	this.deptname = deptname;
}
public int getDesigid() {
	return desigid;
}
public void setDesigid(int desigid) {
	this.desigid = desigid;
}
public String getDesigname() {
	return designame;
}
public void setDesigname(String designame) {
	this.designame = designame;
}
public int getQualid() {
	return qualid;
}
public void setQualid(int qualid) {
	this.qualid = qualid;
}
public String getQualname() {
	return qualname;
}
public void setQualname(String qualname) {
	this.qualname = qualname;
}
public int getAccno() {
	return accno;
}
public void setAccno(int accno) {
	this.accno = accno;
}


}
