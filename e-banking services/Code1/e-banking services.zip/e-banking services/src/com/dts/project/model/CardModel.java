package com.dts.project.model;

public class CardModel {
private int cardtypeid;
private String cardtypename;
private double minbal;
private String status;
private long cardno;
private int custid;
private String custname;
private int custaccno;
private int pinno;
private String applydate;
private String issuedate;
private String txdate;
private int nooftx;


public int getCardtypeid() {
	return cardtypeid;
}
public void setCardtypeid(int cardtypeid) {
	this.cardtypeid = cardtypeid;
}
public String getCardtypename() {
	return cardtypename;
}
public void setCardtypename(String cardtypename) {
	this.cardtypename = cardtypename;
}
public double getMinbal() {
	return minbal;
}
public void setMinbal(double minbal) {
	this.minbal = minbal;
}
public String getStatus() {
	return status;
}
public void setStatus(String status) {
	this.status = status;
}
public long getCardno() {
	return cardno;
}
public void setCardno(long cardno) {
	this.cardno = cardno;
}
public int getCustid() {
	return custid;
}
public void setCustid(int custid) {
	this.custid = custid;
}
public String getCustname() {
	return custname;
}
public void setCustname(String custname) {
	this.custname = custname;
}
public int getCustaccno() {
	return custaccno;
}
public void setCustaccno(int custaccno) {
	this.custaccno = custaccno;
}
public int getPinno() {
	return pinno;
}
public void setPinno(int pinno) {
	this.pinno = pinno;
}
public String getApplydate() {
	return applydate;
}
public void setApplydate(String applydate) {
	this.applydate = applydate;
}
public String getIssuedate() {
	return issuedate;
}
public void setIssuedate(String issuedate) {
	this.issuedate = issuedate;
}
public String getTxdate() {
	return txdate;
}
public void setTxdate(String txdate) {
	this.txdate = txdate;
}
public int getNooftx() {
	return nooftx;
}
public void setNooftx(int nooftx) {
	this.nooftx = nooftx;
}

	
}
