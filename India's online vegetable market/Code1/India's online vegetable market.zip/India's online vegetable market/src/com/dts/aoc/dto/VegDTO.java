package com.dts.aoc.dto;

public class VegDTO {
	private int vegID;
	private String vegName;
	private String vegPic;
	private String vegPicExt;
	private String loginID;
	public int getVegID() {
		return vegID;
	}
	public void setVegID(int vegID) {
		this.vegID = vegID;
	}
	public String getVegName() {
		return vegName;
	}
	public void setVegName(String vegName) {
		this.vegName = vegName;
	}
	public String getVegPic() {
		return vegPic;
	}
	public void setVegPic(String vegPic) {
		this.vegPic = vegPic;
	}
	public String getVegPicExt() {
		return vegPicExt;
	}
	public void setVegPicExt(String vegPicExt) {
		this.vegPicExt = vegPicExt;
	}
	public String getLoginID() {
		return loginID;
	}
	public void setLoginID(String loginID) {
		this.loginID = loginID;
	}
}
