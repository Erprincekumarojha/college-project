package com.dts.aoc.dto;

public class MarketDTO {
	private int marketID;
	private String marketName;
	private String marketAdd;
	private int su;
	private int mo;
	private int tu;
	private int we;
	private int th;
	private int fr;
	private int sa;

	private String loginID;

	public int getMarketID() {
		return marketID;
	}

	public void setMarketID(int marketID) {
		this.marketID = marketID;
	}

	public String getMarketName() {
		return marketName;
	}

	public void setMarketName(String marketName) {
		this.marketName = marketName;
	}

	public String getMarketAdd() {
		return marketAdd;
	}

	public void setMarketAdd(String marketAdd) {
		this.marketAdd = marketAdd;
	}

	public int getSu() {
		return su;
	}

	public void setSu(int su) {
		this.su = su;
	}

	public int getMo() {
		return mo;
	}

	public void setMo(int mo) {
		this.mo = mo;
	}

	public int getTu() {
		return tu;
	}

	public void setTu(int tu) {
		this.tu = tu;
	}

	public int getWe() {
		return we;
	}

	public void setWe(int we) {
		this.we = we;
	}

	public int getTh() {
		return th;
	}

	public void setTh(int th) {
		this.th = th;
	}

	public int getFr() {
		return fr;
	}

	public void setFr(int fr) {
		this.fr = fr;
	}

	public int getSa() {
		return sa;
	}

	public void setSa(int sa) {
		this.sa = sa;
	}

	public String getLoginID() {
		return loginID;
	}

	public void setLoginID(String loginID) {
		this.loginID = loginID;
	}

}
